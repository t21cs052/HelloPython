'''
Created on 2023/12/27

@author: t21cs030
'''
from django.urls import path
from .views import CustomLoginView, LogoutView, SignupView

app_name = 'login'

urlpatterns = [

    path('', CustomLoginView.as_view(), name='loginview'),
    path("logout/", LogoutView.as_view(), name="logout"),
    path('signup/', SignupView.as_view(), name='signup'),

]