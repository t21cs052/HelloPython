'''
Created on 2023/12/27

@author: t21cs030
'''


from django.contrib.auth.views import LoginView, LogoutView
from django.urls import reverse_lazy
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.views.generic.edit import CreateView
from .forms import SignUpForm  


class CustomLoginView(LoginView):
    template_name = 'login/login.html'

    def form_invalid(self, form):
        messages.error(self.request, 'ログインに失敗しました。ユーザー名 または パスワードが正しくありません。')
        return super().form_invalid(form)

    def get_success_url(self):
        if self.request.user.is_superuser:
            # 管理者権限を持っている場合のリダイレクト先
            return reverse_lazy('userchoice:choice_user')  # 例えば、管理者用ダッシュボードのURLを指定する
        else:
            # 一般ユーザーの場合のリダイレクト先
            return reverse_lazy('usermenu:usermenu_view')  # 一般ユーザー用メニューのURLを指定する
          
class LogoutView(LogoutView):
    template_name = 'login/login.html'
    
    

class SignupView(CreateView):
    """ ユーザー登録用ビュー """
    form_class = SignUpForm # 作成した登録用フォームを設定
    template_name = "login/signup.html" 
    success_url = reverse_lazy("login:signup") # ユーザー作成後のリダイレクト先ページ

    def form_valid(self, form):
        # ユーザー作成後にそのままログイン状態にする設定
        response = super().form_valid(form)
        account_id = form.cleaned_data.get("account_id")
        password = form.cleaned_data.get("password1")
        user = authenticate(account_id=account_id, password=password)
        login(self.request, user)
        return response

