'''
Created on 2024/01/18

@author: t21cs030
'''
from django.contrib.auth.forms import UserCreationForm
from DBManagement.models import Employee

class SignUpForm(UserCreationForm):
    class Meta:
        model = Employee
        fields = ('username', 'password1', 'password2', 'age')


