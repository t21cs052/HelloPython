from django.urls import path

from userchoice import views
app_name = 'userchoice'
urlpatterns = [
 
    # urls.py


    path('userchoice/', views.choice_user, name='choice_user'),

]