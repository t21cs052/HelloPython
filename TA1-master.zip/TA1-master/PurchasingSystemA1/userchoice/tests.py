# userchoice/tests.py

from django.test import TestCase
from django.urls import reverse

class ChoiceUserViewsTest(TestCase):
    def test_choice_user_view(self):
        # userchoice:choice_user ビューを呼び出す
        response = self.client.get(reverse('userchoice:choice_user'))

        # 正しいステータスコードが返されるか確認 (200: OK)
        self.assertEqual(response.status_code, 200)

        # 正しいテンプレートが使用されているか確認
        self.assertTemplateUsed(response, 'choice_user/menu.html')
