
from django.shortcuts import render


def choice_user(request):
    return render(request,'choice_user/menu.html')
