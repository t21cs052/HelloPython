'''
概要  ：売上画面の処理を行うアプリ作成
作成日：2023/12/22
更新日：
作成者：猪股
'''
from django.apps import AppConfig


class ProceedConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "proceed"