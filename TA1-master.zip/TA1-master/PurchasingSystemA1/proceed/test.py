# PurchasingSystenA1/proceed/tests/test.py

from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User
from DBManagement.models import Proceed, Item

class ProceedViewsTest(TestCase):
    def setUp(self):
        # テストに使用するユーザーを作成
        self.user = User.objects.create_user(username='testuser', password='testpassword')

        # テストに使用するアイテムを作成
        self.item = Item.objects.create(item_id='test_item', name='Test Item', price=10)

        # テストに使用するProceedデータを作成
        Proceed.objects.create(employee=self.user, item=self.item, unique_id='12345', purchase_count=2, purchase_date='2024-01-22')

    def test_proceed_view_with_post_request(self):
        # POSTリクエストをシミュレート
        response = self.client.post(reverse('proceed'), {'item_id': 'test_item'})

        # 正しいレスポンスが返されることを確認
        self.assertEqual(response.status_code, 200)

        # テンプレート内の変数が正しいことを確認
        self.assertContains(response, 'Test Item')
        self.assertContains(response, '2')  # purchase_countが2であることを確認

    def test_proceed_view_without_post_request(self):
        # GETリクエストをシミュレート
        response = self.client.get(reverse('proceed'))

        # 正しいレスポンスが返されることを確認
        self.assertEqual(response.status_code, 200)

        # テンプレート内の変数が正しいことを確認
        self.assertContains(response, 'Test Item')
        self.assertContains(response, '2')  # purchase_countが2であることを確認

    def test_proceed_item_view(self):
        # アイテム詳細ページのURLを取得
        url = reverse('proceed_item', args=['test_item'])

        # GETリクエストをシミュレート
        response = self.client.get(url)

        # 正しいレスポンスが返されることを確認
        self.assertEqual(response.status_code, 200)

        # テンプレート内の変数が正しいことを確認
        self.assertContains(response, 'Test Item')
        self.assertContains(response, '2024-01-22')  # purchase_dateが正しいことを確認

    def test_export_proceed_to_csv_view(self):
        # CSVエクスポートのURLを取得
        url = reverse('export_proceed_to_csv')

        # GETリクエストをシミュレート
        response = self.client.get(url)

        # 正しいレスポンスが返されることを確認
        self.assertEqual(response.status_code, 200)

        # レスポンスの内容がCSVであることを確認
        self.assertEqual(response['Content-Type'], 'text/csv')
        self.assertTrue(response.content.startswith(b'Proceed ID,Employee ID,Item ID,Unique ID,Purchase Count,Purchase Date,Total Price'))
