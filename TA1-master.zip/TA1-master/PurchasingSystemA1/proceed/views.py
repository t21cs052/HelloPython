import csv
from django.http import HttpResponse
from django.db.models import Sum, F
from django.db.models.functions import TruncMonth
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404
from DBManagement.models import Proceed

@login_required
def proceed(request):
    if request.method == 'POST':
        item_name = request.POST.get('item_name')

        # アイテム名が一致する場合のみデータを取得
        items = Proceed.objects.filter(item__name=item_name).values(
            'item__item_id',
            'item__name'
        ).annotate(
            total_quantity=Sum('purchase_count'),
            total_amount=Sum(F('purchase_count') * F('item__price')),
        )

        # ページ下部のグラフ用データを取得
        proceed_data = Proceed.objects.filter(item__name=item_name).annotate(
            month=TruncMonth('purchase_date')
        ).values('month').annotate(
            total_count=Sum('purchase_count')
        ).order_by('month')

        # 指数平滑法を実行
        smoothed_data = calculate_exponential_smoothing(proceed_data, alpha=0.2)

        labels = [data['month'].strftime('%Y-%m') for data in proceed_data]
        datasets = [{
            'label': item_name,
            'data': [data['total_count'] for data in proceed_data],
            'backgroundColor': 'rgba(75, 192, 192, 0.2)',
            'borderColor': 'rgba(75, 192, 192, 1)',
            'borderWidth': 1
        }]
    else:
        items = None
        labels = []
        datasets = []
        smoothed_data = []

    return render(request, 'proceed.html', {'items': items, 'labels': labels, 'datasets': datasets, 'smoothed_data': smoothed_data})

def proceed_item(request, item_id):
    item = get_object_or_404(Proceed, item__item_id=item_id)
    proceed_data = Proceed.objects.filter(item__item_id=item_id).values('purchase_date', 'purchase_count')

    labels = [data['purchase_date'].strftime('%Y-%m') for data in proceed_data]
    data = [data['purchase_count'] for data in proceed_data]

    return render(request, 'proceed_item.html', {'item': item, 'labels': labels, 'data': data})

def export_proceed_to_csv(request):
    # 以前のコードと同様の処理
    # ...

    # CSVファイルのレスポンスを初期化
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="proceed_data.csv"'

    # CSVライターを初期化
    csv_writer = csv.writer(response)
    
    # CSVのヘッダーを書き込む
    csv_writer.writerow(['Proceed ID', 'Employee ID', 'Item ID', 'Unique ID', 'Purchase Count', 'Purchase Date', 'Total Price'])

    # ProceedモデルのデータをCSVに書き込む
    proceeds = Proceed.objects.all()
    for proceed in proceeds:
        try:
            # 'item'がForeignKeyの場合、関連する'Item'モデルにアクセスして 'price'を取得
            item_price = proceed.item.price if proceed.item else 0
            total_price = proceed.purchase_count * item_price
        except AttributeError:
            # 'item'が見つからない場合に備えてエラーハンドリング
            total_price = 0

        # CSVに書き込む
        csv_writer.writerow([
            proceed.proceed_id,
            proceed.employee,
            proceed.item,
            proceed.unique_id,
            proceed.purchase_count,
            proceed.purchase_date,
            total_price,
        ])

    return response

def calculate_exponential_smoothing(data, alpha):
    smoothed_values = []
    prev_smoothed_value = None  # 初期値

    for entry in data:
        value = entry['total_count']
        # 指数平滑法の初期値設定
        if prev_smoothed_value is None:
            prev_smoothed_value = value

        # 指数平滑法の更新式
        smoothed_value = alpha * value + (1 - alpha) * prev_smoothed_value
        smoothed_values.append(smoothed_value)
        prev_smoothed_value = smoothed_value

    return smoothed_values

