'''
概要  ：売上画面のurlを登録
作成日：2023/12/22
更新日：
作成者：猪股
'''

# PurchasingSystenA1/proceed/urls.py
from django.urls import path
from .views import proceed, export_proceed_to_csv, proceed_item

app_name = 'proceed'

urlpatterns = [
    path('', proceed, name='proceed'),
    path('export-csv/', export_proceed_to_csv, name='export_csv'),
    path('<int:item_id>/', proceed_item, name='proceed_item'),  # 追加: proceed_item パスの追加
]




