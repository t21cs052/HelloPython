from django.shortcuts import render

from DBManagement.models import Item, Proceed, Employee
from datetime import date
import pyqrcode
import re

def camera_view(request):
    return render(request,'paying/camera.html')

def qr_code_result(request):
    if request.method == 'POST':
        
        #QRコードからデータ取得
        result_data = request.POST.get('result')
        if result_data == '':
            #エラー処理
            #AttributeError対策
            #発生条件：Camera画面を3分30秒程度放置/タブ切り替え放置
            return render(request, 'paying/camera_error.html', {'errormessage': 'タイムアウトしました'})
        elif re.match(r"{'item_id': '(\d+)', 'unique_id': '(\d+)'}", result_data) == None:
            #エラー処理
            #AttributeError対策
            #発生条件：正規表現と不一致
            return render(request, 'paying/camera_error.html', {'errormessage': '無効なQRコードを読み取りました'})
        
        #データ成型
        get_item_id = re.search(r"(?<='item_id': ')(\d+)(?=',)", result_data).group()
        get_unique_id = int(re.search(r"(?<='unique_id': ')(\d+)(?=')", result_data).group())
        print(get_item_id)
        print(str(get_unique_id))
        
        #商品データ取得
        paying_item = Item.objects.get(item_id = get_item_id, unique_id = get_unique_id)
        if paying_item.stock_count == 0:
            #エラー処理
            #IntegrityError対策
            #発生条件：ItemDBのstock_count=0の時
            return render(request, 'paying/camera_error.html', {'errormessage': '不正なQRコードを読み取りました'})
        
        #社員データ取得
        get_employee_name = request.user
        
        #商品データ修正
        paying_item.stock_count = paying_item.stock_count - 1
        paying_item.save()
        
        #売上データ作成
        Proceed.objects.create(
            proceed_id = Proceed.objects.all().count(),
            unique_id = get_unique_id,
            purchase_count = 1,
            purchase_date = date.today(),
            employee = Employee.objects.get(username = get_employee_name),
            item = paying_item
            )
        print(Proceed.objects.all().values())
        
        return render(request, 'paying/camera_result.html', {'result_data': result_data, 'paying_item': paying_item})
    else:
        #エラー処理
        #発生条件：get処理等
        return render(request, 'paying/camera_error.html' , {'errormessage': '無効な接続です'})
    

def generate_qr_code(request):
    if request.method == 'GET':
        print(request.session.get('qr_data'))
        #データ取得
        request_data = request.session.get('qr_data') #"{'item_id': '1', 'unique_id': '2'}"
        qr_data = {
            'item_id' : re.search(r"(?<='item_id': ')(\d+)(?=',)", request_data).group(),
            'unique_id' : re.search(r"(?<='unique_id': ')(\d+)(?=')", request_data).group()
            }
        
        #QRコード生成
        qr = pyqrcode.create(request_data)
        img = qr.png_as_base64_str(scale=5)
        
        return render(request, 'paying/create_qr.html', {'qr_code': img, 'qr_data': qr_data})
    else:
        #エラー処理
        #発生条件：get処理等
        return render(request, 'paying/create_qr.html', {'qr_code': ""})


