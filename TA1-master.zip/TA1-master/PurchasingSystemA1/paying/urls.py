'''
Created on 2023/12/26

@author: MIYARIN
修正：t21cs064
'''

from django.urls import path
from . import views
from .views import qr_code_result, generate_qr_code

app_name = 'paying'


urlpatterns = [
    path('paying/QRcodeResult/', qr_code_result, name='qr_code_result'),
    path('paying/', views.camera_view, name='camera_view'),
    path('generate_qr_code/', generate_qr_code, name='generate_qr_code'),
]

