from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractUser
timezone.now()

'''
概要  ：社員DB用社員モデル
作成日：2023/12/15
更新日：2023/12/27
作成者：渡辺
更新：武井
'''

class Employee(AbstractUser):
    age = models.PositiveIntegerField(default=0)
    username = models.CharField(max_length=150, unique=True, blank=True, null=True)
    groups = models.ManyToManyField(
        "auth.Group",
        verbose_name="groups",
        blank=True,
        help_text="The groups this user belongs to.",
        related_name="employee_groups",
        related_query_name="employee_group",
    )
    user_permissions = models.ManyToManyField(
        "auth.Permission",
        verbose_name="user permissions",
        blank=True,
        help_text="Specific permissions for this user.",
        related_name="employee_user_permissions",
        related_query_name="employee_user_permission",
    )

    
    class Meta:
        verbose_name = "Employee"
        

'''
概要  ：業者DB用業者モデル
作成日：2023/12/15
更新日：2023/12/15
作成者：渡辺
'''
class Manufacturer(models.Model):
    manufacturer_id = models.CharField(max_length=10)
    name = models.CharField(max_length=50)
    representative_name = models.CharField(max_length=50)

'''
概要  ：商品DB用商品モデル
作成日：2023/12/15
更新日：2023/12/17
作成者：渡辺
更新：武井
'''

class Item(models.Model):
    item_id = models.CharField(max_length=10, default='1',unique=True)
    unique_id = models.PositiveIntegerField(default=0,)
    name = models.CharField(max_length=50, default='default_name')
    price = models.PositiveIntegerField(default=0)
    best_by_date = models.DateField(default='2023-12-15')  # デフォルトの日付を適切なものに変更
    stock_count = models.PositiveIntegerField(default=0)
    genre_choices = [
        ('food', '食品'),
        ('drink', '飲み物'),
        ('snack', 'お菓子'),
    ]
    genre = models.CharField(max_length=10, choices=genre_choices, null=True)

    def __str__(self):
        return self.name


'''
概要  ：売上DB用売上モデル
作成日：2023/12/15
更新日：2023/1/10
作成者：渡辺
更新：武井
'''

class Proceed(models.Model):
    proceed_id = models.CharField(max_length=10)
    unique_id = models.PositiveIntegerField()
    purchase_count = models.PositiveIntegerField()
    purchase_date = models.DateTimeField()
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, default=1)
    item = models.ForeignKey(Item, on_delete=models.CASCADE,default=1)
