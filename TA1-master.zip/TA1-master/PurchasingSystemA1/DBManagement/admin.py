from django.contrib import admin
from .models import Employee, Manufacturer, Item, Proceed
from django.contrib.auth.admin import UserAdmin

'''
概要  ：admin管理用
作成日：2023/12/15
更新日：2023/12/27
作成者：渡辺
更新：武井
'''

admin.site.register(Employee, UserAdmin)
admin.site.register(Manufacturer)
admin.site.register(Item)
admin.site.register(Proceed)



