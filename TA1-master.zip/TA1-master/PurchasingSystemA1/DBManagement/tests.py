from django.test import TestCase
from django.utils import timezone
from .models import Employee, Manufacturer, Item, Proceed

class EmployeeModelTest(TestCase):
    def test_employee_creation(self):
        employee = Employee.objects.create(username='test_user', age=25)
        self.assertEqual(employee.username, 'test_user')
        self.assertEqual(employee.age, 25)

class ManufacturerModelTest(TestCase):
    def test_manufacturer_creation(self):
        manufacturer = Manufacturer.objects.create(manufacturer_id='123', name='Test Manufacturer', representative_name='John Doe')
        self.assertEqual(manufacturer.manufacturer_id, '123')
        self.assertEqual(manufacturer.name, 'Test Manufacturer')
        self.assertEqual(manufacturer.representative_name, 'John Doe')


class ItemModelTest(TestCase):
    def setUp(self):
        Item.objects.create(name='Drink Item 1', genre='drink', item_id='unique_id_1')

    def test_item_creation(self):
        # Ensure that the item_id used in the test is unique
        item = Item.objects.create(item_id='unique_id_2', name='Test Item', price=50, best_by_date=timezone.now(), stock_count=10, genre='food')
        self.assertEqual(item.name, 'Test Item')
        self.assertEqual(item.price, 50)
        # Additional assertions for other fields

class ProceedModelTest(TestCase):
    def test_proceed_creation(self):
        employee = Employee.objects.create(username='test_user', age=25)
        item = Item.objects.create(item_id='ABC123', name='Test Item', price=50, best_by_date=timezone.now(), stock_count=10, genre='food')
        
        proceed = Proceed.objects.create(proceed_id='P001', unique_id=1, purchase_count=2, purchase_date=timezone.now(), employee=employee, item=item)
        self.assertEqual(proceed.proceed_id, 'P001')
        self.assertEqual(proceed.unique_id, 1)
        self.assertEqual(proceed.purchase_count, 2)
        # 他のフィールドも同様に検証
