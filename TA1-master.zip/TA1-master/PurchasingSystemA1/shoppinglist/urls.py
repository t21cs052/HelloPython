'''
Created on 2023/12/15

@author: t21cs030
'''

from django.urls import path
from . import views
from .views import shopping_list
from .views import ItemAddView, CheckItemIDView, increment_stock

app_name = 'shoppinglist'


urlpatterns = [

    path('list/', views.shopping_list, name='shopping_list'),
    path('', shopping_list, name='shopping_list'),
    path('add', ItemAddView.as_view(), name='add'),   
    path('check_item_id/', CheckItemIDView.as_view(), name='check_item_id'),   
    path('increment_stock/', increment_stock, name='increment_stock'),
]
