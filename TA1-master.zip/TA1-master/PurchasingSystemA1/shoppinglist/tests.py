from django.test import TestCase, Client
from django.urls import reverse
from DBManagement.models import Item


class CheckItemIDViewTest(TestCase):
    def test_check_item_id_view(self):
        # Create a sample item
        Item.objects.create(item_id='123', name='Test Food', genre='food', price=10, best_by_date='2024-01-18', stock_count=5)

        client = Client()
        response = client.get(reverse('shoppinglist:check_item_id'), {'item_id': '123'})

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data['exists'])
        self.assertEqual(data['item']['name'], 'Test Food')
        # Add more assertions as needed

class IncrementStockViewTest(TestCase):
    def test_increment_stock_view(self):
        # Create a sample item
        item = Item.objects.create(item_id='123', name='Test Food', genre='food', price=10, best_by_date='2024-01-18', stock_count=5)

        client = Client()
        data = {
            'item_id': '123',
            'stock_increment': 3,
        }

        response = client.post(reverse('shoppinglist:increment_stock'), data)

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(data['success'])
        self.assertEqual(Item.objects.get(pk=item.pk).stock_count, 8)  # Assuming the initial stock_count is 5
