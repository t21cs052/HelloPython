from django.shortcuts import render
from DBManagement.models import Item
from django.contrib.auth.decorators import login_required
from django.views.generic.edit import CreateView
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.views import View
from django.urls import reverse_lazy, reverse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_protect
from django.db.models import Max
'''
概要  ：listの表示データを取得する
作成日：
更新日：2024/01/18
作成者：猪股
更新：武井
'''

@login_required
def shopping_list(request):

    items = {
        'food' : Item.objects.filter(genre = 'food'),
        'drink' : Item.objects.filter(genre = 'drink'),
        'snack' : Item.objects.filter(genre = 'snack')
        }
    return render(request, 'shoppinglist/shopping_list.html', items)



class ItemAddView(CreateView):
    model = Item
    fields = ['item_id', 'name', 'price', 'best_by_date', 'stock_count', 'genre']  # unique_id を除外
    template_name = 'shoppinglist/item_add.html'
    success_url = reverse_lazy('shoppinglist:shopping_list')

    def form_valid(self, form):
        item_id = form.cleaned_data['item_id']

        # 既存のアイテムが存在するかチェック
        if Item.objects.filter(item_id= form.cleaned_data['item_id']).exists():
            #unique_id計算
            unique_id_max = Item.objects.filter(item_id= form.cleaned_data['item_id']).aggregate(Max('unique_id'))
            unique_id = unique_id_max['unique_id__max'] + 1
        else:
            unique_id = 0
        
        # 既存のアイテムが存在しない場合は新規追加
        form.instance.unique_id = unique_id
        form.save()
        
        # 取得した値をセッションに保存
        self.request.session['qr_data'] = "{'item_id': '" + form.cleaned_data['item_id'] + "', 'unique_id': '" + str(unique_id) + "'}"
        
        return super().form_valid(form)

    def get_success_url(self):
        # リダイレクト先のURLを生成
        return reverse('paying:generate_qr_code')

class CheckItemIDView(View):
    def get(self, request, *args, **kwargs):
        item_id = request.GET.get('item_id')
        item = get_object_or_404(Item, item_id=item_id)
        data = {
            'exists': True,
            'item': {
                'name': item.name,
                'price': item.price,
                'best_by_date': item.best_by_date,
                'stock_count': item.stock_count,
                'genre': item.genre,
            }
        }
        return JsonResponse(data)
    
    
    
@require_POST
@csrf_protect
def increment_stock(request):
    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        stock_increment = request.POST.get('stock_increment')

        try:
            item = Item.objects.get(item_id=item_id)
            item.stock_count += int(stock_increment)
            item.save()
            return JsonResponse({'success': True, 'message': 'Stock incremented successfully'})
        except Item.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Item not found'})
    else:
        return JsonResponse({'success': False, 'message': 'Invalid request method'})
