from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', include('login.urls')),
    path('shoppinglist/', include('shoppinglist.urls')),
    path('shoppinglist/', include('django.contrib.auth.urls')),
    path('proceed/', include('proceed.urls')),
    path('paying/',include('paying.urls', namespace="paying")),
    path('userchoice/',include('userchoice.urls')),
    path('usermenu/',include('usermenu.urls')),
    path('adminmenu/',include('adminmenu.urls')),
]
