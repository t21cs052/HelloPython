from django.urls import path

from adminmenu import views

app_name = 'adminmenu'


urlpatterns = [

    path('', views.adminmenu, name='admin_menu'),
    path('price_setting/', views.price_setting, name='price_setting'),

]