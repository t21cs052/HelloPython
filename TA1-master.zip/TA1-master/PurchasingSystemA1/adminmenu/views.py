from django.shortcuts import render, get_object_or_404
from DBManagement.models import Item


# Create your views here.
def adminmenu(request):
    return render(request,'adminmenu/adminmenu.html')

def price_setting(request):
    # 商品一覧を取得
    items = Item.objects.all()

    if request.method == 'POST':
        # フォームから選択された商品のIDを取得
        selected_item_id = request.POST.get('selected_item')

        if selected_item_id:
            # 選択された商品のIDに対応する商品を取得
            selected_item = get_object_or_404(Item, id=selected_item_id)

            # 商品の価格を半額に設定
            selected_item.price /= 2
            selected_item.save()

            # 半額になった商品名に「（半額）」を追加
            selected_item.name += "（半額）"
            selected_item.save()

            # リダイレクトやメッセージ表示など、適切な処理を追加

    # shoppinglistを取得
    shoppinglist = Item.objects.all()

    return render(request, 'adminmenu/price_setting.html', {'items': items, 'shoppinglist': shoppinglist})