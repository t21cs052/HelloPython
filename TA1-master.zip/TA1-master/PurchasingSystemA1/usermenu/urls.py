from django.urls import path

from usermenu import views
app_name = 'usermenu'
urlpatterns = [
 
    # urls.py


    path('', views.usermenu_view, name='usermenu_view'),

]