from django.shortcuts import render

# Create your views here.
def usermenu_view(request):
    return render(request,'usermenu/usermenu.html')

