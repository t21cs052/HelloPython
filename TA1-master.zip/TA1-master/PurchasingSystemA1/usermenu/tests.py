# usermenu/tests.py

from django.test import TestCase
from django.urls import reverse

class UserMenuViewsTest(TestCase):
    def test_usermenu_view(self):
        # usermenu:usermenu_view ビューを呼び出す
        response = self.client.get(reverse('usermenu:usermenu_view'))

        # 正しいステータスコードが返されるか確認 (200: OK)
        self.assertEqual(response.status_code, 200)

        # 正しいテンプレートが使用されているか確認
        self.assertTemplateUsed(response, 'usermenu/usermenu.html')
